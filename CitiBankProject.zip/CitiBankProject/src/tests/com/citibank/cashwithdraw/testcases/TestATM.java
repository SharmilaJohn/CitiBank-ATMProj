package tests.com.citibank.cashwithdraw.testcases;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

import com.citibank.cashwithdraw.*;

/** @Author:: Sharmila
 * Date: 25-Apr-2024
* Description: Testcases for testing Cash Withdrawl*/

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TestATM {

    BankAccount obj = new BankAccount(); 

               @BeforeEach
                public void init(){
                   BankAccount.calculateTotalCurrency();
                 }

              // Test case to test total available currency
              @Test
              @Order(1)
              public void testCurrency() {
                   assertEquals(3400, BankAccount.getBalance());
               } 

              // Test case to test successful transaction
              @Test
              @Order(2)
              void testSucces() throws InsufficientBalanceException, ZeroBalanceException, InvalidAmountException, NegativeAmountException {
                  assertEquals("Transaction Successful",obj.withdrawCash("Sharon", 250));
                  } 

              // Test case to test for 0 balance
              @Test
              @Order(3)
              void testZeroBalance() {
                       BankAccount.totalCurrency=0;
                       ZeroBalanceException exception = assertThrows(ZeroBalanceException.class, () ->
		       obj.withdrawCash("Sharon", 25000));
		  assertEquals("Sharon Zero Balance", exception.getMessage());
		  } 

              // Test case to test for insufficient balance
              @Test
              @Order(4)
              void testInsufficientBalance() {
                InsufficientBalanceException exception = assertThrows(InsufficientBalanceException.class, () ->
	        obj.withdrawCash("Leon", 500000));
	        assertEquals("Leon Insufficient Balance", exception.getMessage());
          } 

              // Test case to check amount for multiples of 10
              @Test
              @Order(5)
              void testMultiplesOf10() {
                    InvalidAmountException exception = assertThrows(InvalidAmountException.class, () ->
		    obj.withdrawCash("John", 288));
		  assertEquals("John Enter Multiples of 10", exception.getMessage());
                 } 

              // Test case to test for negative amount
              @Test
              @Order(6)
              void testNegativeAmount() {
                   NegativeAmountException exception = assertThrows(NegativeAmountException.class, () ->
		  obj.withdrawCash("Sneha", -28));
		  assertEquals("Sneha Negative Amount", exception.getMessage());
		  } 
}