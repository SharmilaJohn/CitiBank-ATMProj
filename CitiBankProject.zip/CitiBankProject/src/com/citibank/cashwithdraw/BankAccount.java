package com.citibank.cashwithdraw;

 import java.util.logging.Logger;

 
/** @Author:: Sharmila
* Date: 25-Apr-2024
* Description: Cashwithraw transactions with fixed no of currency denominations*/
public class BankAccount {
       final Logger logger = Logger.getLogger(ATMCashWithdraw.class.getName());

       /* Constant Currency Denominations. */
       protected static final int[] currencyDenom = { 1000, 500, 100, 50 , 10 };

       /* Currencies for each denomination*/
       protected static int[] currencyNo = {1,4,2,2,10};
       protected  int[] count = { 0, 0, 0, 0 ,0};
       public static int totalCurrency = 0;

       // Calculates the total currency from the available denominations and count
       public static int calculateTotalCurrency(){      

              for(int i = 0; i < currencyDenom.length; i++){
                     totalCurrency=totalCurrency+currencyDenom[i]*currencyNo[i];
                 }
                  return totalCurrency;
             }

          /* Cash Withdraw   */
             public  synchronized  String  withdrawCash(String name, int amount) throws InsufficientBalanceException, ZeroBalanceException, InvalidAmountException, NegativeAmountException
             {
                    getBalanceNotes();

                    if (totalCurrency<=0)
                          throw new ZeroBalanceException(name+" Zero Balance");
                    else if (amount >= totalCurrency)       
                         throw new InsufficientBalanceException(name+" Insufficient Balance");
                    else if (amount<=0)
                            throw new NegativeAmountException(name+" Negative Amount");
                    else  if(amount%10!=0)
                           throw new InvalidAmountException(name+" Enter Multiples of 10");
                 else if(amount<=totalCurrency)
                 {
                          System.out.println(name+" "+ "is withdrawing");
                     for (int i = 0; i < currencyDenom.length; i++) {
                        if (currencyDenom[i] <= amount) {
                           int countNote = amount / currencyDenom[i];
                           if(currencyNo[i]>0){
                                     count[i] = countNote>=currencyNo[i]?currencyNo[i]:countNote;
                                     currencyNo[i] =  countNote>=currencyNo[i]?0:currencyNo[i]- countNote;
                                     totalCurrency=totalCurrency-(count[i]*currencyDenom[i]);
                                     amount = amount -(count[i]*currencyDenom[i]);
                              }               
                           }
                        }
                     }
                    getNotes();   
                System.out.println(name+" "+ "has completed withdrawal, Balance Amount: " +BankAccount.totalCurrency);
            return "Transaction Successful";
       }

             // Prints the notes available in currency denomination
             private void getNotes(){
                 for (int i = 0; i < count.length; i++) {
                        if (count[i] != 0) {
                             System.out.println(currencyDenom[i] + " * " + count[i] + " = "+ (currencyDenom[i] * count[i]));
                       }
                   }
               }

             // Returns the balance amount
             public static int getBalance()
               {
                    return totalCurrency;
            }

             // Prints the left out denominations
                 private void getBalanceNotes(){
                     for(int i = 0; i < currencyDenom.length; i++){
                         System.out.println("Notes of "+currencyDenom[i]+" left are "+currencyNo[i]);
                     }
                 }
}