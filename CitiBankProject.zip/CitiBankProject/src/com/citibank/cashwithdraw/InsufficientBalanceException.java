package com.citibank.cashwithdraw;

public class InsufficientBalanceException extends Exception{
           public InsufficientBalanceException(String s)
           {
               super(s);
           }
}