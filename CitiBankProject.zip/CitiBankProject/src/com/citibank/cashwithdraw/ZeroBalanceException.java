package com.citibank.cashwithdraw;

public class ZeroBalanceException extends Exception{
           public ZeroBalanceException(String s)
           {
               super(s);
           }
}