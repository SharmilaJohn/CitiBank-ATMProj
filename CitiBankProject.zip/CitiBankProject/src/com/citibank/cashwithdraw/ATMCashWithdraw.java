ackage com.citibank.cashwithdraw;

import java.util.Scanner;

/** @Author:: Sharmila
 * Date: 25-Apr-2024
* Description: Debit thread to access cashwithdraw method*/
class Debit extends Thread
{
       BankAccount acc;
       int amount;
       String name;

       Debit(BankAccount acc, int amount, String name)
       {
             this.acc=acc;
             this.amount=amount;
             this.name=name;
       }

       // Thread to call the withdrawCash method
       @Override
       public void run()
       {
         try
         {
                acc.withdrawCash(name,amount);
         }
         catch(InsufficientBalanceException | ZeroBalanceException | InvalidAmountException | NegativeAmountException e)
         {
                    System.out.println(e.getMessage());
         }
       }
} 

/** @Author:: Sharmila
 * Date: 25-Apr-2024
* Description: Main class for user interfaction to give amount for cash withdraw*/

public class ATMCashWithdraw{
          public static void main(String args[]) {

                /** Method to calculate total currency */
                BankAccount.calculateTotalCurrency();
                BankAccount acc= new BankAccount();
                int debitAmount;

                Scanner sc = new Scanner(System.in);
                System.out.print("Enter amount to withdraw customer 1: ");
                debitAmount = sc.nextInt();
                Debit t1 = new Debit(acc, debitAmount, "Sharon");
                t1.start();

                try {
                       Thread.sleep(2000);
                } catch (InterruptedException e) {
                       e.printStackTrace();
                }

                System.out.print("Enter amount to withdraw customer 2: ");
                debitAmount = sc.nextInt();
                Debit t2 = new Debit(acc, debitAmount,"Leon");
                t2.start();

                try {
                       Thread.sleep(2000);
                } catch (InterruptedException e) {
                       e.printStackTrace();
                }

                System.out.print("Enter amount to withdraw customer 3: ");
                debitAmount = sc.nextInt();
              Debit t3 = new Debit(acc, debitAmount,"Sneha");
                    t3.start();
                    sc.close();
          }
}